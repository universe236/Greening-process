"""Generic temperature-surrogate and adaptive-greening implementation."""
