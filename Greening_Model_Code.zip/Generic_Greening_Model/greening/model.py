"""12-channel U-Net, anti-aliased downsampling and climate conditioning."""

import torch
from torch import nn
from torch.nn import functional as F


class BlurDownsample(nn.Module):
    def __init__(self, channels):
        super().__init__()
        v = torch.tensor([1.0, 2.0, 1.0])
        kernel = (v[:, None] * v[None, :]) / 16.0
        self.register_buffer("kernel", kernel[None, None].repeat(channels, 1, 1, 1))
        self.channels = channels

    def forward(self, x):
        x = F.pad(x, (1, 1, 1, 1), mode="replicate")
        return F.conv2d(x, self.kernel, stride=2, groups=self.channels)


class ConditionedBlock(nn.Module):
    def __init__(self, incoming, outgoing, climate_dim, hidden, groups):
        super().__init__()
        groups = min(groups, outgoing)
        while outgoing % groups:
            groups -= 1
        self.convs = nn.Sequential(
            nn.Conv2d(incoming, outgoing, 3, padding=1),
            nn.GroupNorm(groups, outgoing), nn.SiLU(),
            nn.Conv2d(outgoing, outgoing, 3, padding=1),
            nn.GroupNorm(groups, outgoing), nn.SiLU(),
        )
        self.film = nn.Sequential(
            nn.Linear(climate_dim, hidden), nn.SiLU(),
            nn.Linear(hidden, 2 * outgoing),
        )
        nn.init.zeros_(self.film[-1].weight)
        nn.init.zeros_(self.film[-1].bias)

    def forward(self, x, climate):
        x = self.convs(x)
        scale, offset = self.film(climate).chunk(2, dim=1)
        return x * (1 + scale[:, :, None, None]) + offset[:, :, None, None]


class TemperatureUNet(nn.Module):
    def __init__(self, widths=(32, 64, 128, 256), climate_dim=1,
                 climate_hidden=64, normalization_groups=8):
        super().__init__()
        if len(widths) < 2 or min(widths) < 1 or climate_dim < 1:
            raise ValueError("Use at least two positive widths and one climate feature.")
        args = (climate_dim, climate_hidden, normalization_groups)
        self.encoder = nn.ModuleList()
        self.down = nn.ModuleList()
        incoming = 12
        for i, width in enumerate(widths):
            self.encoder.append(ConditionedBlock(incoming, width, *args))
            if i < len(widths) - 1:
                self.down.append(BlurDownsample(width))
            incoming = width
        self.decoder = nn.ModuleList([
            ConditionedBlock(widths[i + 1] + widths[i], widths[i], *args)
            for i in range(len(widths) - 2, -1, -1)
        ])
        self.head = nn.Conv2d(widths[0], 1, 1)

    def forward10(self, x, climate, background):
        """Return centred temperature on the 10 m grid, including fixed background."""
        if x.shape[1] != 12 or background.shape != x[:, :1].shape:
            raise ValueError("Expected 12 predictors and one co-registered background channel.")
        skips = []
        for i, block in enumerate(self.encoder):
            x = block(x, climate)
            if i < len(self.down):
                skips.append(x)
                x = self.down[i](x)
        for block, skip in zip(self.decoder, reversed(skips)):
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
            x = block(torch.cat((x, skip), dim=1), climate)
        return self.head(x) + background

    def forward(self, x, climate, background):
        """Exactly nine 10 m predictions contribute to each 30 m prediction."""
        if x.shape[-2] % 3 or x.shape[-1] % 3:
            raise ValueError("Tile dimensions must be divisible by 3.")
        return F.avg_pool2d(self.forward10(x, climate, background), 3, 3)
