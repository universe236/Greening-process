"""Aligned arrays, block holdout, train-only preprocessing and nested-grid tiles."""

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from torch.nn import functional as F


def load_config(path):
    cfg = json.loads(Path(path).read_text(encoding="utf-8"))
    return validate_config(cfg)


def validate_config(cfg):
    t, p = cfg["training"], cfg["planning"]
    if t["tile_px"] % 3 or t["tile_stride_px"] % 3:
        raise ValueError("Tile size and stride must be multiples of 3.")
    if t["tile_stride_px"] > t["tile_px"] or t["tile_stride_px"] < 3:
        raise ValueError("Tiles must cover the complete evaluation domain.")
    if t["holdout_block_px"] % 3 or not 0 < t["holdout_fraction"] < 1:
        raise ValueError("Invalid block holdout settings.")
    if p["pixel_size_m"] != 10:
        raise ValueError("This implementation uses the disclosed nested 10 m / 30 m grids.")
    if not 0 < p["target"] <= 1 or not 0 < p["screening_target"] <= 1:
        raise ValueError("Targets are fractions in (0, 1].")
    if not 0 <= p["ndvi_quantile"] <= 1:
        raise ValueError("NDVI quantiles must be in [0, 1].")
    if min(t["iterations"], t["batch_size"], t["log_every"], t["save_every"]) < 1:
        raise ValueError("Iterations, batch size and reporting intervals must be positive.")
    if t["holdout_block_px"] < 3 or t["background_sigma_30m"] <= 0:
        raise ValueError("Block size and background smoothing scale must be positive.")
    if t["learning_rate"] <= 0 or not 0 <= t["minimum_learning_rate"] <= t["learning_rate"]:
        raise ValueError("Learning-rate bounds are invalid.")
    if t["huber_delta_c"] <= 0 or t["gradient_clip"] <= 0 or t["weight_decay"] < 0:
        raise ValueError("Loss and optimization settings are invalid.")
    if p["unit_area_ha"] <= 0 or p["minimum_eligible_ha"] < 0 or p["gradient_steps"] < 1:
        raise ValueError("Unit area and gradient steps must be positive.")
    if p["gradient_step_size"] <= 0 or p["compactness_weight"] < 0:
        raise ValueError("Allocation optimization settings are invalid.")
    if p["route"] not in ("heat", "cool", "random") or not isinstance(p["route_seed"], int):
        raise ValueError("Use a heat, cool or random route and an integer seed.")
    gi, gw = p["green_class_indices"], p["green_class_weights"]
    ei = p["eligible_class_indices"]
    if len(gi) != len(gw) or len(set(gi)) != len(gi) or not np.isclose(sum(gw), 1):
        raise ValueError("Green class weights must be nonnegative and sum to one.")
    if min(gw) < 0 or set(gi) & set(ei) or any(i not in range(7) for i in gi + ei):
        raise ValueError("Green and eligible classes must be disjoint indices in 0..6.")
    return cfg


def stable_seed(city_id, seed):
    payload = (str(city_id) + ":" + str(seed)).encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


def block_mean(a):
    h, w = a.shape[-2:]
    if h % 3 or w % 3:
        raise ValueError("A 30 m block must contain exactly 3 x 3 input cells.")
    return a.reshape(*a.shape[:-2], h // 3, 3, w // 3, 3).mean(axis=(-3, -1))


def weighted_median(values, weights):
    good = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    v, w = values[good], weights[good]
    if not len(v):
        raise ValueError("No valid values for the weighted median.")
    order = np.argsort(v, kind="stable")
    v, w = v[order], w[order]
    return float(v[np.searchsorted(np.cumsum(w), w.sum() / 2)])


def load_city(path, climate_dim):
    with np.load(path, allow_pickle=False) as z:
        required = ("landcover", "ndvi", "height", "building", "urban", "lst", "climate")
        missing = [name for name in required if name not in z]
        if missing:
            raise ValueError(f"{path}: missing arrays {missing}")
        city = {name: np.array(z[name]) for name in required}
        city["city_id"] = str(z["city_id"].item()) if "city_id" in z else Path(path).stem
    shape = city["landcover"].shape
    if len(shape) != 2 or min(shape) < 3 or shape[0] % 3 or shape[1] % 3:
        raise ValueError("10 m dimensions must be positive multiples of 3.")
    if any(city[name].shape != shape for name in required[:5]):
        raise ValueError("All 10 m arrays must share their shape and grid origin.")
    if city["lst"].shape != (shape[0] // 3, shape[1] // 3):
        raise ValueError("LST must use the nested 30 m grid with the same upper-left origin.")
    for key in ("urban", "building"):
        if not np.isin(city[key], (0, 1)).all():
            raise ValueError(f"{key} must contain only 0 and 1.")
        city[key] = city[key].astype(bool)
    lc = city["landcover"]
    if not np.isin(lc, [-1, 0, 1, 2, 3, 4, 5, 6]).all():
        raise ValueError("Land cover must use classes 0..6 and -1 for missing data.")
    city["climate"] = city["climate"].astype(np.float32).reshape(-1)
    if len(city["climate"]) != climate_dim or not np.isfinite(city["climate"]).all():
        raise ValueError("Invalid climate feature vector.")
    city["urban30"] = block_mean(city["urban"].astype(np.float32))
    if city["urban30"].sum() <= 0:
        raise ValueError("The city has no urban cells.")
    return city


def spatial_holdout(city, cfg):
    t = cfg["training"]
    valid = np.isfinite(city["lst"]) & (city["urban30"] > 0)
    h, w = valid.shape
    block = t["holdout_block_px"] // 3
    y, x = np.indices((h, w))
    ids = (y // block) * math.ceil(w / block) + x // block
    available = np.unique(ids[valid])
    if len(available) < 2:
        raise ValueError("At least two spatial blocks with valid LST are needed for holdout.")
    rng = np.random.default_rng(stable_seed(city["city_id"], cfg["seed"]))
    n = min(len(available) - 1, max(1, round(len(available) * t["holdout_fraction"])))
    held = rng.choice(available, n, replace=False)
    test = valid & np.isin(ids, held)
    return valid & ~test, test


def fit_preprocessing(cities, train_masks):
    """Fit every label-derived component using training cells only."""
    stats = {}
    for name in ("ndvi", "height"):
        count, total, squared = 0, 0.0, 0.0
        for city, mask in zip(cities, train_masks):
            m10 = mask.repeat(3, 0).repeat(3, 1) & city["urban"]
            a = city[name].astype(np.float64)
            valid = np.isfinite(a) & m10
            if name == "height":
                valid &= a >= 0
                a = np.log1p(np.maximum(a, 0))
            a = a[valid]
            count += a.size
            total += a.sum()
            squared += np.square(a).sum()
        if not count:
            raise ValueError(f"No training values for {name}.")
        mean = total / count
        scale = max(float(np.sqrt(max(squared / count - mean * mean, 0))), 1e-6)
        stats[name] = {"mean": float(mean), "scale": scale}
    climates = np.stack([c["climate"] for c in cities]).astype(np.float64)
    scale = climates.std(0)
    scale[scale < 1e-6] = 1.0
    stats["climate"] = {"mean": climates.mean(0).tolist(), "scale": scale.tolist()}
    return stats


def make_features(city, stats):
    lc = city["landcover"]
    channels = [(lc == k).astype(np.float32) for k in range(7)]
    valid_masks = [(lc >= 0).astype(np.float32)]
    for name in ("ndvi", "height"):
        a = city[name].astype(np.float64)
        valid = np.isfinite(a)
        if name == "height":
            valid &= a >= 0
            a = np.log1p(np.maximum(a, 0))
        scaled = (a - stats[name]["mean"]) / stats[name]["scale"]
        channels.append(np.where(valid, scaled, 0).astype(np.float32))
        valid_masks.append(valid.astype(np.float32))
    channels.extend(valid_masks)
    return np.stack(channels)


def city_context(city, train_mask, cfg):
    median = weighted_median(city["lst"], city["urban30"] * train_mask)
    target = city["lst"].astype(np.float64) - median
    weights = city["urban30"] * train_mask
    sigma = cfg["training"]["background_sigma_30m"]
    numerator = gaussian_filter(np.where(train_mask, target, 0) * weights, sigma, mode="nearest")
    denominator = gaussian_filter(weights, sigma, mode="nearest")
    background = np.divide(numerator, denominator, out=np.zeros_like(numerator), where=denominator > 1e-8)
    return median, background.repeat(3, 0).repeat(3, 1).astype(np.float32)


def pack_city(city, stats, cfg, train=None, test=None, context=None):
    if train is None:
        train, test = spatial_holdout(city, cfg)
    median, background = city_context(city, train, cfg) if context is None else context
    climate = (city["climate"] - stats["climate"]["mean"]) / stats["climate"]["scale"]
    return {
        **city, "x": torch.from_numpy(make_features(city, stats)),
        "background": torch.from_numpy(background[None]),
        "climate_tensor": torch.tensor(climate, dtype=torch.float32),
        "label": torch.tensor(np.where(np.isfinite(city["lst"]), city["lst"] - median, 0), dtype=torch.float32)[None],
        "train_mask": np.asarray(train), "test_mask": np.asarray(test), "median": median,
    }


def axis_origins(length, tile, stride):
    return list(range(0, max(0, math.ceil((length - tile) / stride)) * stride + 1, stride))


def tile_origins(shape, tile, stride):
    return [(y, x) for y in axis_origins(shape[0], tile, stride)
            for x in axis_origins(shape[1], tile, stride)]


def crop_pad(a, y, x, size, replicate=False):
    crop = a[..., y:y + size, x:x + size]
    dh, dw = size - crop.shape[-2], size - crop.shape[-1]
    if not dh and not dw:
        return crop
    if replicate:
        # F.pad's replicate mode expects at least one channel axis.
        return F.pad(crop.unsqueeze(0), (0, dw, 0, dh), mode="replicate").squeeze(0)
    return F.pad(crop, (0, dw, 0, dh))


def device_from_config(cfg):
    if cfg["device"] == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(cfg["device"])
