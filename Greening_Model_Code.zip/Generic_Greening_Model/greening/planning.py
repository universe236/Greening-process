"""Regular hexagons, projected-gradient allocation and matched planning rules."""

from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from .data import crop_pad, stable_seed, validate_config
from .engine import TiledEvaluator, restore, write_json


NEIGHBOURS = ((1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1))


def hexagonal_units(shape, pixel_size_m, area_ha):
    """Pointy-top regular hexagons, assigned by pixel-centre cube rounding."""
    if area_ha <= 0:
        raise ValueError("Hexagon area must be positive.")
    radius = np.sqrt(2 * area_ha * 10000 / (3 * np.sqrt(3)))
    yy, xx = np.indices(shape, dtype=np.float64)
    xx, yy = (xx + 0.5) * pixel_size_m, (yy + 0.5) * pixel_size_m
    q = (np.sqrt(3) * xx / 3 - yy / 3) / radius
    r = (2 * yy / 3) / radius
    s = -q - r
    qi, ri, si = np.rint(q), np.rint(r), np.rint(s)
    dq, dr, ds = abs(qi - q), abs(ri - r), abs(si - s)
    fixq = (dq > dr) & (dq > ds)
    fixr = ~fixq & (dr > ds)
    qi[fixq] = -ri[fixq] - si[fixq]
    ri[fixr] = -qi[fixr] - si[fixr]
    coords, inverse = np.unique(np.stack((qi, ri), -1).reshape(-1, 2).astype(np.int64), axis=0, return_inverse=True)
    labels = inverse.reshape(shape)
    lookup = {tuple(coord): i for i, coord in enumerate(coords)}
    neighbours = {i: {lookup[(q + dq, r + dr)] for dq, dr in NEIGHBOURS if (q + dq, r + dr) in lookup}
                  for i, (q, r) in enumerate(coords)}
    return labels, neighbours


def select_units(city, p):
    labels, neighbours = hexagonal_units(city["urban"].shape, p["pixel_size_m"], p["unit_area_ha"])
    eligible = city["urban"] & ~city["building"] & np.isin(city["landcover"], p["eligible_class_indices"])
    eligible &= np.isfinite(city["ndvi"]) & np.isfinite(city["height"]) & (city["height"] >= 0)
    pixel_area = p["pixel_size_m"] ** 2
    units = {}
    for uid in np.unique(labels[city["urban"]]):
        core = (labels == uid) & city["urban"]
        mask = core & eligible
        core_count, available = int(core.sum()), int(mask.sum())
        screening_count = int(np.floor(p["screening_target"] * core_count + 0.5))
        if (screening_count > 0 and available >= screening_count
                and available * pixel_area >= p["minimum_eligible_ha"] * 10000):
            k = min(available, int(np.floor(p["target"] * core_count + 0.5)))
            units[int(uid)] = {"eligible": mask, "core": core, "count": k}
    if not units:
        raise ValueError("No planning units passed the stated selection rules.")
    return labels, neighbours, units


def new_green_values(city, stats, p):
    existing = np.isin(city["landcover"], p["green_class_indices"]) & city["urban"] & np.isfinite(city["ndvi"])
    if not existing.any():
        raise ValueError("The city has no valid existing-green NDVI values.")
    raw_ndvi = float(np.quantile(city["ndvi"][existing], p["ndvi_quantile"]))
    vector = np.zeros(12, dtype=np.float32)
    vector[p["green_class_indices"]] = p["green_class_weights"]
    vector[7] = (raw_ndvi - stats["ndvi"]["mean"]) / stats["ndvi"]["scale"]
    vector[8] = -stats["height"]["mean"] / stats["height"]["scale"]
    vector[9:] = 1.0
    return torch.from_numpy(vector), raw_ndvi


def apply_allocation(features, selected, green_values):
    result = features.clone()
    mask = torch.as_tensor(selected, dtype=torch.bool, device=result.device)
    result[:, mask] = green_values.to(result.device)[:, None]
    return result


def project_budget(values, eligible, count):
    """Euclidean projection onto 0 <= a <= 1, sum(a)=count, outside a=0."""
    with torch.no_grad():
        if count == 0:
            return torch.zeros_like(values)
        if count == int(eligible.sum()):
            return eligible.to(values.dtype)
        v = values[eligible]
        low, high = v.min() - 1, v.max()
        for _ in range(48):
            middle = (low + high) / 2
            if torch.clamp(v - middle, 0, 1).sum() > count:
                low = middle
            else:
                high = middle
        result = torch.zeros_like(values)
        result[eligible] = torch.clamp(v - (low + high) / 2, 0, 1)
        return result


def compactness(alpha, count):
    """Anisotropic total variation, including the outer boundary, per green pixel."""
    a = F.pad(alpha, (1, 1, 1, 1))
    perimeter = (a[1:, :] - a[:-1, :]).abs().sum() + (a[:, 1:] - a[:, :-1]).abs().sum()
    return perimeter / max(2 * count, 1)


def intensity_tile(alpha, bounds, origin, tile, shape):
    """Place a unit-local differentiable intensity into an aligned evaluation tile."""
    y0, y1, x0, x1 = bounds
    y, x = origin
    h, w = min(tile, shape[0] - y), min(tile, shape[1] - x)
    top, bottom = max(y, y0), min(y + h, y1)
    left, right = max(x, x0), min(x + w, x1)
    part = alpha[top - y0:bottom - y0, left - x0:right - x0]
    part = F.pad(part, (left - x, x + w - right, top - y, y + h - bottom))[None]
    if h != tile or w != tile:
        part = F.pad(part[None], (0, tile - w, 0, tile - h), mode="replicate")[0]
    return part


def optimise_allocation(evaluator, features, eligible, count, green_values, p):
    available = int(eligible.sum())
    if not 0 <= count <= available:
        raise ValueError("Allocation exceeds eligible pixels.")
    if count == 0 or count == available:
        return eligible.copy() if count else np.zeros_like(eligible)
    ys, xs = np.where(eligible)
    bounds = (int(ys.min()), int(ys.max()) + 1, int(xs.min()), int(xs.max()) + 1)
    y0, y1, x0, x1 = bounds
    mask = torch.tensor(eligible[y0:y1, x0:x1], device=evaluator.device)
    alpha = mask.float() * (count / available)
    green = green_values.to(evaluator.device)[:, None, None]
    # Only tiles influenced by this allocation enter the gradient graph.
    patches = []
    weight_sum = 0.0
    for y, x in evaluator.affected_origins(eligible):
        base = crop_pad(features, y, x, evaluator.tile, replicate=True).to(evaluator.device)
        bg = crop_pad(evaluator.background, y, x, evaluator.tile, replicate=True)[None]
        weight = evaluator.tile_weight(y, x)
        patches.append((y, x, base, bg, weight))
        weight_sum += float(weight.sum())
    if weight_sum <= 0:
        raise ValueError("Allocation has no urban evaluation support.")
    for _ in range(p["gradient_steps"]):
        alpha = alpha.detach().requires_grad_(True)
        temperature = alpha.sum() * 0
        for y, x, base, bg, weight in patches:
            intensity = intensity_tile(alpha, bounds, (y, x), evaluator.tile, evaluator.shape)
            candidate = base * (1 - intensity) + green * intensity
            prediction = evaluator.model(candidate[None], evaluator.climate, bg)[0]
            temperature = temperature + (prediction * weight).sum() / weight_sum
        loss = temperature + p["compactness_weight"] * compactness(alpha, count)
        gradient, = torch.autograd.grad(loss, alpha)
        if not torch.isfinite(gradient).all():
            raise FloatingPointError("Non-finite allocation gradient.")
        rms = gradient[mask].square().mean().sqrt().clamp_min(1e-8)
        alpha = project_budget(alpha - p["gradient_step_size"] * gradient / rms, mask, count)
    scores = alpha.detach().cpu().numpy()
    local_mask = eligible[y0:y1, x0:x1]
    indices = np.flatnonzero(local_mask)
    order = np.argsort(-scores.ravel()[indices], kind="stable")[:count]
    local = np.zeros_like(local_mask)
    local.ravel()[indices[order]] = True
    selected = np.zeros_like(eligible)
    selected[y0:y1, x0:x1] = local
    return selected


def implementation_route(units, neighbours, initial_temperature, kind, city_id, seed=1):
    if kind not in ("heat", "cool", "random"):
        raise ValueError("Route must be heat, cool or random.")
    temp10 = initial_temperature.repeat(3, 0).repeat(3, 1)
    scores = {uid: float(temp10[unit["core"]].mean()) for uid, unit in units.items()}
    remaining, frontier, route = set(units), set(), []
    rng = np.random.default_rng(stable_seed(city_id, seed))
    while remaining:
        candidates = sorted(frontier & remaining) or sorted(remaining)
        if kind == "random":
            uid = int(rng.choice(candidates))
        elif kind == "heat":
            uid = min(candidates, key=lambda i: (-scores[i], i))
        else:
            uid = min(candidates, key=lambda i: (scores[i], i))
        route.append(uid)
        remaining.remove(uid)
        frontier.discard(uid)
        frontier.update(neighbours[uid] & remaining)
    return route


def plan_city(model, city, cfg, stats, device, output_dir):
    p = cfg["planning"]
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    labels, neighbours, units = select_units(city, p)
    evaluator = TiledEvaluator(model, city, cfg, device)
    initial = city["x"]
    temperature0 = evaluator.predict(initial)
    green, raw_ndvi = new_green_values(city, stats, p)
    order = implementation_route(units, neighbours, temperature0, p["route"],
                                 city["city_id"], p["route_seed"])
    np.savez_compressed(output / "initial.npz", prediction=temperature0, unit_id=labels,
                        urban_fraction=city["urban30"], retained_unit_ids=np.array(sorted(units)))
    for rule in ("blueprint", "adaptive"):
        current = initial.clone()
        allocation = np.zeros(city["urban"].shape, dtype=bool)
        for stage, uid in enumerate(order, 1):
            unit = units[uid]
            reference = initial if rule == "blueprint" else current
            selected = optimise_allocation(evaluator, reference, unit["eligible"], unit["count"], green, p)
            current = apply_allocation(current, selected, green)
            allocation |= selected
            print(f"{city['city_id']}: {rule} {stage}/{len(order)}", flush=True)
        np.savez_compressed(output / f"{rule}.npz", allocation=allocation,
                            prediction=evaluator.predict(current), route=np.asarray(order), ndvi=raw_ndvi)


def plan(checkpoint, input_dir, output_dir, overrides=None):
    model, cities, cfg, stats, device = restore(checkpoint, input_dir)
    # These defaults also allow checkpoints made with the earlier configuration.
    cfg["planning"].setdefault("route", "heat")
    cfg["planning"].setdefault("route_seed", 1)
    if overrides:
        cfg["planning"].update(overrides)
    validate_config(cfg)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "config.json", cfg)
    index = []
    for i, city in enumerate(cities):
        folder = f"city_{i:04d}"
        plan_city(model, city, cfg, stats, device, output / folder)
        index.append({"city_id": city["city_id"], "folder": folder})
    write_json(output / "cities.json", index)
    return index
