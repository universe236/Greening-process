"""Training, tiled prediction and genuine spatial-block holdout evaluation."""

import csv
import hashlib
import json
import random
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from .data import (crop_pad, device_from_config, fit_preprocessing, load_city,
                   pack_city, spatial_holdout, tile_origins)
from .model import TemperatureUNet


def fingerprint(city):
    digest = hashlib.sha256()
    for name in ("landcover", "ndvi", "height", "building", "urban", "lst", "climate"):
        a = np.ascontiguousarray(city[name])
        digest.update(str((name, a.shape, a.dtype.str)).encode())
        digest.update(a.tobytes())
    return digest.hexdigest()


def load_cities(folder, cfg):
    paths = sorted(Path(folder).glob("*.npz"))
    if not paths:
        raise ValueError("The input directory contains no city .npz files.")
    cities = [load_city(p, cfg["model"]["climate_dim"]) for p in paths]
    if len({c["city_id"] for c in cities}) != len(cities):
        raise ValueError("City identifiers must be unique.")
    return cities


class TiledEvaluator:
    """Same tile origins, 3 x 3 pooling and urban weights for every landscape."""
    def __init__(self, model, city, cfg, device):
        self.model, self.city, self.device = model, city, device
        self.tile = cfg["training"]["tile_px"]
        self.stride = cfg["training"]["tile_stride_px"]
        self.shape = city["urban"].shape
        self.origins = tile_origins(self.shape, self.tile, self.stride)
        self.background = city["background"].to(device)
        self.climate = city["climate_tensor"].to(device)[None]
        coverage = np.zeros(city["urban30"].shape, dtype=np.float64)
        n = self.tile // 3
        for y, x in self.origins:
            coverage[y // 3:y // 3 + n, x // 3:x // 3 + n] += 1
        if np.any(coverage == 0):
            raise RuntimeError("Uncovered evaluation cells.")
        self.coverage = coverage
        self.weights = torch.tensor(
            city["urban30"] / coverage / city["urban30"].sum(),
            dtype=torch.float32, device=device,
        )[None]

    def tile_prediction(self, features, y, x):
        patch = crop_pad(features, y, x, self.tile, replicate=True).to(self.device)[None]
        bg = crop_pad(self.background, y, x, self.tile, replicate=True)[None]
        return self.model(patch, self.climate, bg)[0]

    def tile_weight(self, y, x):
        return crop_pad(self.weights, y // 3, x // 3, self.tile // 3)

    def affected_origins(self, mask):
        """Padded edge pixels repeat the last real pixel in their tile."""
        return [(y, x) for y, x in self.origins if mask[y:y + self.tile, x:x + self.tile].any()]

    @torch.no_grad()
    def predict(self, features):
        prediction = np.zeros_like(self.coverage)
        n = self.tile // 3
        for y, x in self.origins:
            p = self.tile_prediction(features, y, x)[0].cpu().double().numpy()
            y3, x3 = y // 3, x // 3
            h, w = prediction[y3:y3 + n, x3:x3 + n].shape
            prediction[y3:y3 + h, x3:x3 + w] += p[:h, :w]
        return prediction / self.coverage + self.city["median"]



def write_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")


def save_checkpoint(path, model, optimizer, scheduler, cfg, stats, packed, step):
    contexts = {
        c["city_id"]: {
            "median": c["median"], "background": c["background"].clone(),
            "train_mask": torch.from_numpy(c["train_mask"]),
            "test_mask": torch.from_numpy(c["test_mask"]), "fingerprint": fingerprint(c),
        } for c in packed
    }
    obj = {
        "model": model.state_dict(), "config": cfg, "preprocessing": stats,
        "contexts": contexts, "step": step,
        "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, temporary)
    temporary.replace(path)


def train(input_dir, cfg, output_dir):
    random.seed(cfg["seed"])
    np.random.seed(cfg["seed"])
    torch.manual_seed(cfg["seed"])
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(cfg["seed"])
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    device = device_from_config(cfg)
    raw = load_cities(input_dir, cfg)
    splits = [spatial_holdout(c, cfg) for c in raw]
    stats = fit_preprocessing(raw, [s[0] for s in splits])
    cities = [pack_city(c, stats, cfg, *s) for c, s in zip(raw, splits)]
    t = cfg["training"]
    origins = []
    for city in cities:
        usable = []
        for y, x in tile_origins(city["urban"].shape, t["tile_px"], t["tile_stride_px"]):
            if city["train_mask"][y // 3:(y + t["tile_px"]) // 3,
                                  x // 3:(x + t["tile_px"]) // 3].any():
                usable.append((y, x))
        if not usable:
            raise ValueError(f"{city['city_id']}: no training tiles.")
        origins.append(usable)
    model = TemperatureUNet(**cfg["model"]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=t["learning_rate"], weight_decay=t["weight_decay"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=t["iterations"], eta_min=t["minimum_learning_rate"],
    )
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "config.json", cfg)
    write_json(output / "preprocessing.json", stats)
    rng = np.random.default_rng(cfg["seed"])
    with (output / "training_loss.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["iteration", "weighted_huber_loss", "learning_rate"])
        model.train()
        for step in range(1, t["iterations"] + 1):
            fields = {key: [] for key in ("x", "background", "climate", "label", "weight")}
            for _ in range(t["batch_size"]):
                ci = int(rng.integers(len(cities)))
                city = cities[ci]
                y, x = origins[ci][int(rng.integers(len(origins[ci])))]
                for key in ("x", "background"):
                    fields[key].append(crop_pad(city[key], y, x, t["tile_px"], replicate=True))
                fields["climate"].append(city["climate_tensor"])
                fields["label"].append(crop_pad(city["label"], y // 3, x // 3, t["tile_px"] // 3))
                weights = torch.tensor(city["urban30"] * city["train_mask"], dtype=torch.float32)[None]
                fields["weight"].append(crop_pad(weights, y // 3, x // 3, t["tile_px"] // 3))
            batch = {key: torch.stack(values).to(device) for key, values in fields.items()}
            optimizer.zero_grad(set_to_none=True)
            pred = model(batch["x"], batch["climate"], batch["background"])
            errors = F.huber_loss(pred, batch["label"], reduction="none", delta=t["huber_delta_c"])
            loss = (errors * batch["weight"]).sum() / batch["weight"].sum()
            if not torch.isfinite(loss):
                raise FloatingPointError("Training produced a non-finite loss.")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), t["gradient_clip"])
            optimizer.step()
            scheduler.step()
            if step == 1 or step % t["log_every"] == 0 or step == t["iterations"]:
                value = float(loss.detach())
                writer.writerow([step, value, optimizer.param_groups[0]["lr"]])
                stream.flush()
                print(f"iteration {step}/{t['iterations']}: loss={value:.6f}", flush=True)
            if step % t["save_every"] == 0 or step == t["iterations"]:
                save_checkpoint(output / "model.pt", model, optimizer, scheduler, cfg, stats, cities, step)
    return output / "model.pt"


def restore(checkpoint, input_dir):
    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=True)
    cfg = ckpt["config"]
    device = device_from_config(cfg)
    model = TemperatureUNet(**cfg["model"]).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    cities = []
    for city in load_cities(input_dir, cfg):
        if city["city_id"] not in ckpt["contexts"]:
            raise ValueError("This command expects cities with saved training/holdout contexts.")
        context = ckpt["contexts"][city["city_id"]]
        if fingerprint(city) != context["fingerprint"]:
            raise ValueError(f"{city['city_id']}: inputs differ from the saved training inputs.")
        cities.append(pack_city(
            city, ckpt["preprocessing"], cfg,
            context["train_mask"].numpy(), context["test_mask"].numpy(),
            (context["median"], context["background"][0].numpy()),
        ))
    return model, cities, cfg, ckpt["preprocessing"], device


def weighted_metrics(reference, prediction, weight):
    error = prediction - reference
    s = float(weight.sum())
    mean = float(np.sum(reference * weight) / s)
    mse = float(np.sum(weight * error ** 2) / s)
    variance = float(np.sum(weight * (reference - mean) ** 2) / s)
    return {"n": int(len(error)), "rmse_c": mse ** 0.5,
            "bias_c": float(np.sum(weight * error) / s),
            "r2": 1 - mse / variance if variance > 0 else None}


def evaluate(checkpoint, input_dir, output_dir):
    model, cities, cfg, _, device = restore(checkpoint, input_dir)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    rows, references, predictions, weights = [], [], [], []
    for index, city in enumerate(cities):
        pred = TiledEvaluator(model, city, cfg, device).predict(city["x"])
        mask = city["test_mask"]
        ref, fitted, weight = city["lst"][mask], pred[mask], city["urban30"][mask].astype(np.float64)
        rows.append({"city_id": city["city_id"], **weighted_metrics(ref, fitted, weight)})
        references.append(ref)
        predictions.append(fitted)
        weights.append(weight)
        np.savez_compressed(output / f"prediction_{index:04d}.npz", city_id=city["city_id"],
                            prediction=pred, reference=city["lst"], holdout_mask=mask,
                            urban_fraction=city["urban30"])
    result = {"cities": rows, "pooled": weighted_metrics(np.concatenate(references),
              np.concatenate(predictions), np.concatenate(weights))}
    write_json(output / "holdout_metrics.json", result)
    return result
